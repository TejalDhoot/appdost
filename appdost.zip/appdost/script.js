// Footer Year
document.addEventListener("DOMContentLoaded",()=>{
  const yearEl=document.getElementById("year");
  if(yearEl)yearEl.textContent=new Date().getFullYear();
});

// Reveal-on-scroll
const reveals=document.querySelectorAll('.reveal');
function revealElements(){
  const trigger=window.innerHeight*0.85;
  reveals.forEach(el=>{
    const top=el.getBoundingClientRect().top;
    if(top<trigger)el.classList.add('visible');
  });
}
window.addEventListener('scroll',revealElements);
window.addEventListener('load',revealElements);

// Smooth page fade-in
window.addEventListener('load',()=>{
  document.body.style.opacity=0;
  document.body.style.transition="opacity .6s ease-in-out";
  requestAnimationFrame(()=>document.body.style.opacity=1);
});

// 🌗 Dark Mode Toggle
const themeToggle=document.getElementById("themeToggle");
if(themeToggle){
  themeToggle.addEventListener("click",()=>{
    document.body.classList.toggle("dark-mode");
    const isDark=document.body.classList.contains("dark-mode");
    themeToggle.innerHTML=isDark
      ?'<i class="bi bi-sun"></i> Light'
      :'<i class="bi bi-moon"></i> Dark';
    localStorage.setItem("theme",isDark?"dark":"light");
  });
  // Load preference
  const saved=localStorage.getItem("theme");
  if(saved==="dark"){
    document.body.classList.add("dark-mode");
    themeToggle.innerHTML='<i class="bi bi-sun"></i> Light';
  }
}
